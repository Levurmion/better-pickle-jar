betterpicklejar is a wrapper library around the Python pickle module.

It automatically handles the management of pickle files into 'Jars' for each file, all of which are contained within a 'pickle_shelf' directory.