#!/bin/bash

pickle_jar=$1

mkdir "$pickle_jar"