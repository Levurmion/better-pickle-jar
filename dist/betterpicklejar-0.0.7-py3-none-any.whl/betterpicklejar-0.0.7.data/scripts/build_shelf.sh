#!/bin/bash

pickle_shelf=$1

mkdir "$pickle_shelf"